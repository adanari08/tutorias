/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author lessl
 */
public class DatosTablaCitas {
    private Tutorado t; //tutorado
    private Boolean asistencia; // asistencia
    private String accion;
    
    public DatosTablaCitas(Tutorado tutorado){
        t = tutorado;
        asistencia = false;
        accion = new String();
    }
    
    public Tutorado getT(){
        return t;
    }
    
    public void setT(Tutorado t){
        this.t = t;
    }
    
    public Boolean getAsistencia(){
        return asistencia;
    }
    
    public void setAsistencia(Boolean asistencia){
        this.asistencia = asistencia;
    }
    
    public String getAccion(){
        return accion;
    }
    
    public void setAccion(String accion){
        this.accion = accion;
    }
    
}
