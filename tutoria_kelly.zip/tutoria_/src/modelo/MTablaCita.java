/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author lessl
 */
public class MTablaCita extends AbstractTableModel{
    private ArrayList<DatosTablaCitas> datosCitas;
    private String encabezados[] = {"Tutorado", "Asistencia", "Acción"};
    private Class clasesC[] = {String.class, Boolean.class, String.class};
    
    public MTablaCita(ArrayList mtc){
        datosCitas = mtc;
    }
    
    public boolean isCellEditable(int r, int c){
        if(c == 1) return true; //asistencia
        if(c == 2){
            if(datosCitas.get(r).getAsistencia())
                return true;
        }
        return false;
    }
    
    public String getColumnName(int c){
        return encabezados[c];
    }

    @Override
    public int getRowCount() {
        return datosCitas.size()+1;
    }

    @Override
    public int getColumnCount() {
        return encabezados.length;
    }
public void actualizar(List<DatosTablaCitas> nuevosDatos) {
        this.datosCitas = new ArrayList<>(nuevosDatos);
        fireTableDataChanged(); // Notifica a la tabla que los datos han cambiado
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex < datosCitas.size())
            switch (columnIndex) {
                case 0:
                    return datosCitas.get(rowIndex).getT().getNombre();
                case 1:
                    return datosCitas.get(rowIndex).getAsistencia();
                case 2:
                    return datosCitas.get(rowIndex).getAccion();
                default:
                    return null;
            }
        else if(columnIndex == 2){
            return "Asistencia: " + asistencia();
        }
        return null;
    }
    public int asistencia(){
        int nta = 0;
        for(int a = 0; a < datosCitas.size(); a++)
            if(datosCitas.get(a).getAsistencia())
                nta++;
            return nta;
    }
    @Override
    public void setValueAt(Object obj, int rowIndex, int columnIndex) {
        if (columnIndex == 1) {
            datosCitas.get(rowIndex).setAsistencia((Boolean) obj);
            fireTableDataChanged();
            
        }
        if (columnIndex == 2 && datosCitas.get(rowIndex).getAsistencia()) {
            datosCitas.get(rowIndex).setAccion((String) obj);
            fireTableDataChanged();
        }

    }
}
